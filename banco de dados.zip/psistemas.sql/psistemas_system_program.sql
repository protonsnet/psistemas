-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: u722026046_psistemas
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `system_program`
--

DROP TABLE IF EXISTS `system_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_program` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `controller` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_program`
--

LOCK TABLES `system_program` WRITE;
/*!40000 ALTER TABLE `system_program` DISABLE KEYS */;
INSERT INTO `system_program` VALUES (1,'System Group Form','SystemGroupForm'),(2,'System Group List','SystemGroupList'),(3,'System Program Form','SystemProgramForm'),(4,'System Program List','SystemProgramList'),(5,'System User Form','SystemUserForm'),(6,'System User List','SystemUserList'),(7,'Common Page','CommonPage'),(8,'System PHP Info','SystemPHPInfoView'),(9,'System ChangeLog View','SystemChangeLogView'),(10,'Welcome View','WelcomeView'),(11,'System Sql Log','SystemSqlLogList'),(12,'System Profile View','SystemProfileView'),(13,'System Profile Form','SystemProfileForm'),(14,'System SQL Panel','SystemSQLPanel'),(15,'System Access Log','SystemAccessLogList'),(16,'System Message Form','SystemMessageForm'),(17,'System Message List','SystemMessageList'),(18,'System Message Form View','SystemMessageFormView'),(19,'System Notification List','SystemNotificationList'),(20,'System Notification Form View','SystemNotificationFormView'),(21,'System Document Category List','SystemDocumentCategoryFormList'),(26,'System Unit Form','SystemUnitForm'),(27,'System Unit List','SystemUnitList'),(28,'System Access stats','SystemAccessLogStats'),(29,'System Preference form','SystemPreferenceForm'),(30,'System Support form','SystemSupportForm'),(31,'System PHP Error','SystemPHPErrorLogView'),(32,'System Database Browser','SystemDatabaseExplorer'),(33,'System Table List','SystemTableList'),(34,'System Data Browser','SystemDataBrowser'),(35,'System Menu Editor','SystemMenuEditor'),(36,'System Request Log','SystemRequestLogList'),(37,'System Request Log View','SystemRequestLogView'),(38,'System Administration Dashboard','SystemAdministrationDashboard'),(39,'System Log Dashboard','SystemLogDashboard'),(40,'System Session dump','SystemSessionDumpView'),(41,'System Information','SystemInformationView'),(42,'System files diff','SystemFilesDiff'),(43,'System Documents','SystemDriveList'),(44,'System Folder form','SystemFolderForm'),(45,'System Share folder','SystemFolderShareForm'),(46,'System Share document','SystemDocumentShareForm'),(47,'System Document properties','SystemDocumentFormWindow'),(48,'System Folder properties','SystemFolderFormView'),(49,'System Document upload','SystemDriveDocumentUploadForm'),(52,'System Post list','SystemPostList'),(53,'System Post form','SystemPostForm'),(54,'Post View list','SystemPostFeedView'),(55,'Post Comment form','SystemPostCommentForm'),(56,'Post Comment list','SystemPostCommentList'),(57,'System Contacts list','SystemContactsList'),(58,'System Wiki list','SystemWikiList'),(59,'System Wiki form','SystemWikiForm'),(60,'System Wiki search','SystemWikiSearchList'),(61,'System Wiki view','SystemWikiView'),(62,'Categoria Consulta','CategoryCons'),(63,'Cadastro Categoria','CategoryForm');
/*!40000 ALTER TABLE `system_program` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-26 10:49:00
